BEGIN TRANSACTION;
CREATE TABLE audit_logs (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	action VARCHAR NOT NULL, 
	resource_type VARCHAR, 
	resource_id INTEGER, 
	details VARCHAR, 
	ip_address VARCHAR, 
	user_agent VARCHAR, 
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
INSERT INTO "audit_logs" VALUES(1,19,'registration',NULL,NULL,NULL,'testclient','testclient','2026-04-18 12:31:35');
INSERT INTO "audit_logs" VALUES(2,20,'registration',NULL,NULL,NULL,'testclient','testclient','2026-04-18 12:31:56');
INSERT INTO "audit_logs" VALUES(3,20,'login_success',NULL,NULL,NULL,'testclient','testclient','2026-04-18 12:32:02');
CREATE TABLE billing_events (
	id INTEGER NOT NULL, 
	subscription_id INTEGER NOT NULL, 
	event_type VARCHAR NOT NULL, 
	payload JSON, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(subscription_id) REFERENCES user_subscriptions (id)
);
CREATE TABLE email_verification_tokens (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	token VARCHAR NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
CREATE TABLE password_reset_tokens (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	token VARCHAR NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
CREATE TABLE pets (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	name VARCHAR NOT NULL, 
	species VARCHAR NOT NULL, 
	breed VARCHAR, 
	birth_date DATE, 
	weight FLOAT, 
	notes TEXT, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
INSERT INTO "pets" VALUES(1,1,'dogo','dog',NULL,'2025-12-02',NULL,NULL,'2026-02-02 16:31:23.175877');
CREATE TABLE refresh_tokens (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	token_hash VARCHAR NOT NULL, 
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP, 
	expires_at DATETIME NOT NULL, 
	is_revoked BOOLEAN NOT NULL, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
INSERT INTO "refresh_tokens" VALUES(1,20,'643615a5001ae6e2ef49c1446547ccc6f7b56b02b39c49aa895cc8bb4db7198a','2026-04-18 12:32:02','2026-04-25 12:32:02.722442',0,NULL);
CREATE TABLE reminder_logs (
	id INTEGER NOT NULL, 
	reminder_id INTEGER NOT NULL, 
	scheduled_at DATETIME NOT NULL, 
	executed_at DATETIME, 
	status VARCHAR(7) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(reminder_id) REFERENCES reminders (id)
);
CREATE TABLE reminders (
	id INTEGER NOT NULL, 
	pet_id INTEGER NOT NULL, 
	title VARCHAR NOT NULL, 
	description TEXT, 
	reminder_type VARCHAR(10) NOT NULL, 
	frequency VARCHAR(7) NOT NULL, 
	time TIME NOT NULL, 
	days_of_week JSON, 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(pet_id) REFERENCES pets (id)
);
CREATE TABLE routine_logs (
	id INTEGER NOT NULL, 
	task_id INTEGER NOT NULL, 
	date DATE NOT NULL, 
	status VARCHAR NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(task_id) REFERENCES routine_tasks (id)
);
INSERT INTO "routine_logs" VALUES(1,1,'2026-02-03','done');
CREATE TABLE routine_tasks (
	id INTEGER NOT NULL, 
	routine_id INTEGER NOT NULL, 
	type VARCHAR NOT NULL, 
	frequency VARCHAR NOT NULL, 
	time TIME NOT NULL, 
	active BOOLEAN, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(routine_id) REFERENCES routines (id)
);
INSERT INTO "routine_tasks" VALUES(1,1,'ra��o','daily','10:00:00.000000',1,'2026-02-03 10:54:40.293117');
CREATE TABLE routines (
	id INTEGER NOT NULL, 
	pet_id INTEGER NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (pet_id), 
	FOREIGN KEY(pet_id) REFERENCES pets (id)
);
INSERT INTO "routines" VALUES(1,1,'2026-02-02 16:31:23.178760');
CREATE TABLE settings (
	id INTEGER NOT NULL, 
	"key" VARCHAR NOT NULL, 
	value VARCHAR NOT NULL, 
	description TEXT, 
	updated_at DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO "settings" VALUES(1,'registration_enabled','true','Enable/disable user registration','2026-01-29 16:20:02.364646');
INSERT INTO "settings" VALUES(2,'max_pets_per_user','3','Maximum pets allowed per user (free plan)','2026-01-29 16:20:02.364650');
INSERT INTO "settings" VALUES(3,'max_routines_per_pet','10','Maximum routine tasks per pet','2026-01-29 16:20:02.364652');
INSERT INTO "settings" VALUES(4,'require_email_verification','false','Require email verification before login','2026-04-17 19:46:32.910673');
CREATE TABLE subscription_plans (
	id INTEGER NOT NULL, 
	code VARCHAR NOT NULL, 
	name VARCHAR NOT NULL, 
	monthly_price_cents INTEGER NOT NULL, 
	trial_days INTEGER NOT NULL, 
	max_pets INTEGER NOT NULL, 
	max_routines_per_pet INTEGER NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE user_subscriptions (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	plan_id INTEGER NOT NULL, 
	status VARCHAR(8) NOT NULL, 
	cancel_at_period_end BOOLEAN NOT NULL, 
	current_period_start DATETIME NOT NULL, 
	current_period_end DATETIME NOT NULL, 
	trial_ends_at DATETIME, 
	provider VARCHAR, 
	provider_subscription_id VARCHAR, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(plan_id) REFERENCES subscription_plans (id)
);
CREATE TABLE users (
	id INTEGER NOT NULL, 
	name VARCHAR NOT NULL, 
	email VARCHAR NOT NULL, 
	password_hash VARCHAR NOT NULL, 
	created_at DATETIME, is_active BOOLEAN DEFAULT 1, is_superuser BOOLEAN DEFAULT 0, updated_at DATETIME, email_verified BOOLEAN DEFAULT 0, is_2fa_enabled BOOLEAN DEFAULT 0, totp_secret VARCHAR, backup_codes JSON DEFAULT '[]', last_2fa_verification DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO "users" VALUES(1,'aza','aza@email.com','$2b$12$hGIlBAAOulsn5UEPqHbbNeTWacTzCWejb3wODK5S9vsRksuLrGdca','2026-01-28 18:55:51.650797',1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(2,'ale','ale@email.com','$2b$12$lNXddB7wh0lyINLyZz7fKOyJ6smvW8pwSrR3XsvlJ3fZEqOC0wxMy','2026-01-29 16:21:10.216203',1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(4,'Admin','admin@admin.com','$2b$12$pI3XTYD62Qq/A2H166Y4M.ChpIXv8WQzUhq0E0rl8fmj1S2nG2kCO','2026-01-29 16:37:24.968835',1,1,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(5,'Vitoria','vitoria@lanature.com','$2b$12$0nhsj0IEt0Yxkujtc/4rDeauGW1QAqVFDYWYSesLhUE5tYAImM3h2',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(6,'Vitoria','vitoria2@lanature.com','$2b$12$mq8Ly8UMb.JZ4QR1X/aDgeacxL6HLX8jYJAgeVHHS3WvWmUewQTmO',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(7,'Vitoria Codetria','vitoria@codetria.dev','$2b$12$KXC7Pf3ng6oDhUV0RMmP1u53ruVbc1Y5472xSgZ0qo7qiKe5hRDiq',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(8,'Test User','test@example.com','$2b$12$9O5fFkRM7ZPSNDPgzRKz5uMlf3hezIcfQNHO9RaajxeQFOYSs.vey',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(9,'Vitoria','vit@example.com','$2b$12$dcT9KfvFOvatcAsPqg2MBOXN50bzfaGn9Eks6L00fum1PZg7kgigO',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(10,'Vitoria Codetria','vit@lanature.com','$2b$12$zp6XTW1YcanhwmHL3.NGSOrbfOPS63VnAJYnVWu/z7psjhjKyQ0.G',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(11,'Vitoria Test','vitoria@test.com','$2b$12$PXLIvHcunSs8OmxMndpThOnK17bNoUh7Fvy.bUZlAFuFyPfJ/s7u2',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(12,'Vitoria','vitoria.codetria@lanature.com','$2b$12$x./lOlIckjsAQYKbSa2kgOVrAo5.1sP5.pRF4sZueKqutbC0kQsdq',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(13,'Test User','test123@example.com','$2b$12$bnROb/mGPuFff31XX/BHWeEFnEYADcHb5Izz1PesXBTcFNJkh2Nri',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(14,'Vitoria Teste','vitoria.teste@lanature.com','$2b$12$i4lXE.lGVCpWlsRssMzXduUTwCLp2njKW53Yr.c0IG2XxbPOj6zUe',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(15,'Vitoria Novo','vitoria.novo@lanature.com','$2b$12$yj1N.ukXLYuKGTTRxM.w8.NRLExTbqqxvZl.qO9YWsmB6/XgCMtyq',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(16,'Test User','test.user@lanature.com','$2b$12$jm5j/aXUGzCGYgOEdeIQnOACQpYqqYYBkDgLBoIX/WaXZzC7pZ.Tq',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(17,'Test User','testuser123@example.com','$2b$12$sKp6qLIrf31aPZV31wld5uRMQejsalgsKKHr8VociBBEDgXzxhd2G',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(18,'Test User','testuser124@example.com','$2b$12$AMmDt8.2aJDRfJBRd52cOOgHi9YgvIBDWDbaqogBtrzMbVbb.NVpm',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(19,'Test User','testuser999@example.com','$2b$12$CSLLeKHU.78D/n0HvCBSle7HvuKodiSEGo3zrNYVM8PVZsqSz2Jra',NULL,1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(20,'Test User','testuser1001@example.com','$2b$12$fOzT1uoYx4yzrg7Q9v.1Q.6knYQTsTuQV/j21McuP/GQeuxcq63W6','2026-04-18 12:31:56.405699',1,0,NULL,0,0,NULL,'[]',NULL);
INSERT INTO "users" VALUES(21,'Test Admin','testadmin@test.com','$2b$12$eBcajuBUsbjEmGeBOQzqleah/DIHvqnrEwGBWSPE/jf8ypfe93YXO','2026-04-18 12:33:29.066513',1,1,NULL,0,0,NULL,'[]',NULL);
CREATE UNIQUE INDEX ix_users_email ON users (email);
CREATE INDEX ix_users_id ON users (id);
CREATE INDEX ix_pets_id ON pets (id);
CREATE INDEX ix_routines_id ON routines (id);
CREATE INDEX ix_reminders_id ON reminders (id);
CREATE INDEX ix_routine_tasks_id ON routine_tasks (id);
CREATE INDEX ix_reminder_logs_id ON reminder_logs (id);
CREATE INDEX ix_routine_logs_id ON routine_logs (id);
CREATE UNIQUE INDEX ix_settings_key ON settings ("key");
CREATE INDEX ix_settings_id ON settings (id);
CREATE INDEX ix_refresh_tokens_user_id ON refresh_tokens (user_id);
CREATE INDEX ix_refresh_tokens_id ON refresh_tokens (id);
CREATE UNIQUE INDEX ix_refresh_tokens_token_hash ON refresh_tokens (token_hash);
CREATE INDEX ix_password_reset_tokens_id ON password_reset_tokens (id);
CREATE UNIQUE INDEX ix_password_reset_tokens_token ON password_reset_tokens (token);
CREATE INDEX ix_audit_logs_created_at ON audit_logs (created_at);
CREATE INDEX ix_audit_logs_id ON audit_logs (id);
CREATE INDEX ix_audit_logs_user_id ON audit_logs (user_id);
CREATE INDEX ix_audit_logs_action ON audit_logs (action);
CREATE UNIQUE INDEX ix_email_verification_tokens_token ON email_verification_tokens (token);
CREATE INDEX ix_email_verification_tokens_id ON email_verification_tokens (id);
CREATE UNIQUE INDEX ix_subscription_plans_code ON subscription_plans (code);
CREATE INDEX ix_subscription_plans_id ON subscription_plans (id);
CREATE INDEX ix_user_subscriptions_id ON user_subscriptions (id);
CREATE INDEX ix_user_subscriptions_user_id ON user_subscriptions (user_id);
CREATE INDEX ix_billing_events_id ON billing_events (id);
CREATE INDEX ix_billing_events_subscription_id ON billing_events (subscription_id);
COMMIT;
